const express = require('express');
const app = express();

//중간프로그램(미들웨어)
app.use(express.static(__dirname + '/memo'));


app.listen(8080,()=>{
    console.log('localhost:8080포트로 서버 열림')
})

app.get('/',(res,req)=>{
    res.sendFile(__dirname+'/memo/index.html');
})