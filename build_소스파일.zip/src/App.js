import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <img src={logo} className="App-logo" alt="logo" />
      <div>
          Memo Notes
      </div>
      <nav class="navbar navbar-expand-lg navbar-light">
          <div class="container-fluid">
          <a class="navbar-brand" href="/">Memo Notes</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
              <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="/">Memo List</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="/">Memo</a>
              </li>
              </ul>
          </div>
          </div>
      </nav>
      <div class="write">
        <div class="list">
          <ul class="list-group">
          <li class="list-group-item">주소보내야할것</li>
          <li class="list-group-item">자주가는 쇼핑몰 사이트 목록</li>
          <li class="list-group-item">오늘 해야할것</li>
          <li class="list-group-item">오늘 사야할것</li>
          <li class="list-group-item">여행가기전에 준비할것</li>
        </ul>
        </div>
        <div class="memo">
          <div class="memopage">
            <div class="mb-3" id="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Memo Title</label>
            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="메모 제목을 적어주세요"></input>
            </div>
            <div class="mb-3">
              <label for="exampleFormControlTextarea1" class="form-label">Memo Content</label>
              <textarea class="form-control" id="exampleFormControlTextarea1" rows="6"></textarea>
            </div>
            <button type="button" class="btn btn-outline-secondary">메모하기</button>
          </div>
          
        </div>
      </div>
        
    </div>
  );
}

export default App;
